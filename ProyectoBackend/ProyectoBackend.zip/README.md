# Proyecto Proyecto Backend :monocle_face:

Archivos iniciales del proyecto para  FullStack.
localhost/ProyectoFrontEnd/ProyectoBackend/admin
para ingreso al administrador backend y almacenar en base de datos
- Ajustar ruta en header.php para correr en rutas distintas a la original o xampp
