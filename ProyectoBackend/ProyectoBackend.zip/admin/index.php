<?php include ("templates/header.php");?>
<br>
<div class="p-5 mb-4 bg-light rounded-3">
    <div class="container-fluid py-5">
      <h1 class="display-5 fw-bold">Administración del Sitio Web</h1>
      <p class="col-md-8 fs-4">Estos módulos estan diseñados para que nuestros clientes administren los contenidos, imagenes, etc. con la información que requieran.</p>
    </div>
  </div>

<?php include ("templates/footer.php");?>